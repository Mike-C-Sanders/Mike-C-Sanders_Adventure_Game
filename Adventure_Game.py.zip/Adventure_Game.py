import time
import random

weak_weapon = [
            'walking stick', 'dagger', 'water jug', 'prayer beads',
            'fork', 'spoon', 'cross']

power_weapons = [
            'Excalibur', 'Axe of Perun', "Thor's' Hammer",
            'The Bow of Heracules', 'The Golden Dragon Cresent Blade']

creatures = ['Dragon', 'Witch', 'Oger', 'Giant', 'Demon', 'Gorgon', 'Troll']


def print_pause(message):

    print(message)
    time.sleep(2)


def valid_input():

    while True:
        choice = input("Please enter 1 or 2.\n")
        if '1' == choice:
            break
        elif '2' == choice:
            break
        else:
            print_pause("That's not a valid input")
    return choice


def intro(items, boss, starting_weapon, legendary_weapon):
    print_pause("You find yourself standing in an open field,"
                "filled with grass and yellow wildflowers.")
    print_pause(f"Rumor has it that an evil {boss} is somewhere around here, "
                "and has been terrifying the nearby village.")
    print_pause("...")
    print_pause("In front of you is the castle")
    print_pause("To your right is a dark cave.")
    print_pause(f"In your hand you hold your trusty (but not so effective) "
                f"{starting_weapon}.")


def cave(items, boss, starting_weapon, legendary_weapon):

    if starting_weapon in items:
        items = legendary_weapon
        print_pause("You peer into the cave, and something"
                    "shinny catches your eye under a pile of rocks.")
        print_pause(f"Pulling the rocks and boulders off the object, "
                    f"you discover it's {legendary_weapon}!")
        print_pause(f"Considering your options, you discared your "
                    f"{starting_weapon} and replace it "
                    f"with {legendary_weapon}.")
        field(items, boss, starting_weapon, legendary_weapon)
    else:
        print_pause("You've been here before. Looks like you've grabbed "
                    "all the good stuff. ")
        print_pause("It's just an empy cave now.")
        print_pause("You walk back to the field.")
        field(items, boss, starting_weapon, legendary_weapon)


def castle(items, boss, starting_weapon, legendary_weapon):
    print_pause("You approach the door of the castle.")
    print_pause(f"You are about to knock on the "
                "door when the castle door opens.")
    print_pause(f"It's the {boss}, looking ugly as usual.")
    print_pause(f"The {boss} attackes!")

    print_pause("Would you like to (1) Fight or (2) Run Away?")
    choice = valid_input()
    if '1' == choice:
        fight(items, boss, starting_weapon, legendary_weapon)
    else:
        print_pause("You run back to the field!")
        print_pause(f"Fortunately it doesn't look like the "
                    f"{boss} followed you.")
        field(items, boss, starting_weapon, legendary_weapon)


def field(items, boss, starting_weapon, legendary_weapon):
    print_pause("Enter 1 to knock on the door of the castle.")
    print_pause("Enter 2 to explore the dark cave.")
    print_pause("What would you like to do?")
    choice = valid_input()
    if '1' == choice:
        castle(items, boss, starting_weapon, legendary_weapon)
    elif '2' == choice:
        cave(items, boss, starting_weapon, legendary_weapon)


def fight(items, boss, starting_weapon, legendary_weapon):
    if legendary_weapon in items:
        print_pause(f"The {boss} sees your {items} "
                    "and roars in anger")
        print_pause("Get ready for a fight!!!")
        attack(items, boss)

    else:
        print_pause(f"You do your best, but the {items}"
                    f"is no match for the {boss}.")
        print_pause("You've been defeated.")
        GAME_OVER()


def attack(items, boss):
    hits = 0
    dice = [0, 1]
    chance = 0
    while True:
        chance = random.choice(dice)
        print_pause(f"Enter 1 or 2 to swing {items} at the {boss}\n"
                    f"and attack the {boss}")
        attack = valid_input()
        if chance == 1:
            hits += 1
            if hits == 1:
                print_pause(f"{items}, "
                            f"sings in your hand and you spring to action!")
                print_pause(f"You land a solid hit. The {boss} is wounded.")
                print_pause(f"It's not over yet!")
            elif hits == 2:
                print_pause(f"The {boss} runs towards you... ")
                print_pause(f"But you're too quick!")
                print_pause(f"You dodge to the side land a solid second hit "
                            "right to the face!")
                print_pause(f"The {boss} is knocked sideways!")
                print_pause(f"The {boss} ROARS AND SHAKES WITH RAGE!\n"
                            f"Making a last stand, the ugly beast staggers. "
                            "Snarling, turning to face you.")
                print_pause("Still not defeated. "
                            "You stand ready...")
            elif hits == 3:
                print_pause(f"Before the {boss} can react you dart forward, "
                            f"with your {items} in hand.")
                print_pause(f"You successfully land your final blow "
                            f"on the {boss}'s chest.")
                print_pause(f"In a screeching moan the {boss} "
                            "collapses.")
                break
        else:
            print_pause(f"You swing {items} at the {boss}, but miss....")

    print_pause(f"You've defeated the evil {boss}.")
    print_pause("The village is safe!")
    print_pause("Good work!!!!")
    GAME_OVER()


def play_game():
    boss = random.choice(creatures)
    starting_weapon = random.choice(weak_weapon)
    legendary_weapon = random.choice(power_weapons)
    items = starting_weapon
    intro(items, boss, starting_weapon, legendary_weapon)
    field(items, boss, starting_weapon, legendary_weapon)


def GAME_OVER():
    print_pause("GAME OVER\n")
    again = input("Would you like to play again? (y/n)\n")
    if 'y' in again:
        play_game()
    elif 'n' in again:
        return


play_game()
